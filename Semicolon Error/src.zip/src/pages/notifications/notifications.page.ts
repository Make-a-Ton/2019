import { Component, OnInit } from '@angular/core';
import { DataService } from '../../service/data.service';
import { AuthService } from '../../service/auth.service';
import { Platform } from '@ionic/angular';
import { Downloader, DownloadRequest, NotificationVisibility } from '@ionic-native/downloader/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { stringify } from '@angular/core/src/util';
import { viewAttached } from '@angular/core/src/render3/instructions';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.page.html',
  styleUrls: ['./notifications.page.scss'],
})
export class NotificationsPage implements OnInit {
  
  not={subtitle:"",message:"",user:"",dept:"",flag:-1,url:"",fname:"",ftype:MimeType};
  // upfile={name:"",type: MimeType,content:"ntfn",date:""};
  notflag=0;
  fileup:any;
  files: [];
  pgbar=[];
  notdata:any;
  pgarray:[];
  // fref={ref:"notref"};
  constructor(private dataService: DataService, 
              private authService: AuthService,
              private platform:Platform,
              private downloader:Downloader,
              private fileopener:FileOpener) { }


  upfile={name:"",type: MimeType,content:"nots"};
  fref={ref:"nots"};
  fileToUpload: File = null;

  handleFileInput(event) {
    const fil=event.target.files;
    this.upfile.name=fil[0].name;
    this.upfile.type=fil[0].type;
    let files: FileList=event.target.files;
    this.fileToUpload = files.item(0);
    this.dataService.postFile(this.fileToUpload,this.upfile);
}

  
// fchange(event){
//   const files=event.target.files;
//   console.log(files);
//   console.log(event)    
//   console.log(event.target);

//   let d=new Date();
//   let dt=d.toLocaleDateString();
  

//   this.upfile.name=files[0].name;
//   this.upfile.type=files[0].type;
//   this.upfile.date=dt;

//   console.log(this.upfile.type);
//   this.dataService.fileTransfers(this.upfile,"notification"); // uploading info about upfile to db
// this.dataService.uploads(event,"notification/"+this.upfile.name)//uploading file to storage
//   .then((d)=>{
//     alert("Done");
//     this.dataService.fileref(this.fref).then(data=>{
//       this.files=JSON.parse( data.data);
//       });
//   }).catch((error)=>{
//     alert(JSON.stringify(error))
//   });
// }

fchange(event){
  this.fileup=event;
  if(event.target.files.length>0)
  {
    this.notflag=1;
    console.log("not flag: "+this.notflag)
  }
  else
  {
    this.notflag=0;
    console.log("not flag: "+this.notflag) 
  }
  console.log(this.fileup);
  const files=event.target.files;
  console.log("event.target.files");
  console.log(files);
  console.log("event.target") ;   
  console.log(event.target);

  // let d=new Date();
  // let dt=d.toLocaleDateString();

  this.upfile.name=files[0].name;
  this.upfile.type=files[0].type;
  // this.upfile.date=dt;
  console.log("upfile");
  console.log(this.upfile);

//   console.log(this.upfile.type);
  // this.dataService.fileTransfers(this.upfile,"notification"); // uploading info about upfile to db
// this.dataService.uploads(event,"notification/"+this.upfile.name)//uploading file to storage
//   .then((d)=>{
//     alert("Done");
//     this.dataService.fileref(this.fref).then(data=>{
//       this.files=JSON.parse( data.data);
//       });
//   }).catch((error)=>{
//     alert(JSON.stringify(error))
//   });
}

async flist(){
 
  await this.dataService.fileref(this.fref).then(data=>{
    console.log("news.ts")
    console.log(data.data);
         
   // this.dataService.pgbar.pop();
  
    this.files=JSON.parse( data.data);
    console.log(this.files);
   for(let x of this.files){
    this.dataService.pgbar[x["filename"]]=0;
    console.log("x");
    console.log(x);
   }
   console.log("pgbar");
   console.log(this.dataService.pgbar);
    });

}



// dwnld(fname,ftype){
// console.log("type:  "+ftype);
// this.dataService.dwnlds(fname,ftype,"notification");
// // alert("ts: "+fname);
// }

dwnld(fname,ftype){
  console.log("type:  "+ftype);
  this.dataService.sample(fname);
  }
  
  texts()
  {
    this.dataService.v_not().then((data)=>{
      console.log("view nots");
          this.notdata=data.data});
  }

doRefresh(event)
{

  this.dataService.fileref((this.fref)).then(data=>{
  
          console.log(this.notdata);
   
    //  alert("refresh");
       this.files=JSON.parse( data.data);
       console.log(this.files);
      for(let x of this.files){
       this.dataService.pgbar[x["filename"]]=0;
       console.log("x");
       console.log(x);
       if(this.files.length>0){
         console.log("length"+this.files.length);
         event.target.complete();
       }
      }
      console.log("pgbar");
      console.log(this.dataService.pgbar);
      this.texts();
       });
}
// doRefresh(event){

//   // this.dataService.fileref((this.fref)).then(data=>{
 
//   // //  alert("refresh");
//   //    this.files=JSON.parse( data.data);
//   //    console.log(this.files);
//   //   for(let x of this.files){
//   //    this.dataService.pgbar[x["filename"]]=0;
//   //    console.log("x");
//   //    console.log(x);
//   //    if(this.files.length>0){
//   //      console.log("length"+this.files.length);
//   //      event.target.complete();
//   //    }
//   //   }
//   //   console.log("pgbar");
//   //   console.log(this.dataService.pgbar);
//   //    });
//   this.dataService.nots().then((data)=>{
//     this.notdata=JSON.parse(data.data);
//     console.log("new notdata:   ");
//     console.log(this.notdata);
//     event.target.complete();
//     // for(let x of this.notdata){
//     //   if(this.notdata.flag==1)
//     //   {
//     //     this.pgbar[x["fname"]]=0;
//     //    console.log("x");
//     //    console.log(x);
//     //   }
      
//     //  }
//     //  console.log("new pgbar:   "+this.pgbar);
//   });
    
//   }
// notify()
// {
//   if(this.notflag==1)
//   {
//     // alert("Sending Notification with attachments");
//   this.dataService.uploads(this.fileup,"notification/"+this.upfile.name)//uploading file to storage
//     .then((d)=>{
//       var notfileref=this.dataService.afstorage.ref("notification").child(this.upfile.name);
//       notfileref.getDownloadURL().subscribe((url)=>{
//         console.log("storage file upld res"); 
//         console.log(d); 
//         alert("Done");
//         this.not.flag=this.notflag;
       
//           this.not.url=url;
//           this.not.fname=this.upfile.name;
//           this.not.ftype=this.upfile.type;
//           this.authService.notify(this.not).then((res)=>  this.nots());
//           this.nots();
        
//       });
//     }).catch((error)=>{
//         console.log(error);
//       });
//     }
//         else
//         {
//           // alert("Sending Notification");
//           this.not.flag=this.notflag;
//           this.not.ftype=null;
//           this.not.url="nofile";
//           this.not.fname="nofile";
//           this.authService.notify(this.not).then((res)=>  this.nots());
//           this.nots();
          
//         }
//         console.log(this.not); 
//         // this.authService.notify(this.not);

   
      
//       // this.dataService.fileref(this.fref).then(data=>{
//       //   this.files=JSON.parse( data.data);
//       //   });
    
//   // this.not.flag=this.notflag;
//   // console.log(this.not); 
//   // this.authService.notify(this.not);
  
// }
notify()
{
  this.dataService.p_not(this.not).then(()=>console.log("nn"));
}

view()
{
  this.dataService.v_not().then((idea)=>{
    this.notdata=JSON.parse(idea.data);
    console.log(this.notdata);
  })
}

nots()
{
  this.dataService.nots().then((data)=>{
    this.notdata=JSON.parse(data.data);
    console.log("new notdata:   ");
    console.log(this.notdata);
    // for(let x of this.notdata){
    //   if(this.notdata.flag==1)
    //   {
    //     this.pgbar[x["fname"]]=0;
    //    console.log("x");
    //    console.log(x);
    //   }
      
    //  }
    //  console.log("new pgbar:   "+this.pgbar);
  })

}
down(url,fname,ftype)
{

  var self=this;
      // alert(url+fname+ftype);
if(this.platform.is("desktop"))
{
  console.log("cordova");
    let oReq = new XMLHttpRequest();
    //SENDING REQUEST
    oReq.open("GET",url, true);
    oReq.responseType = "blob"; // blob pls
    // // oReq.setRequestHeader('Access-Control-Allow-Headers', '*');
  
    // //IF DATA RECEIVED THEN  WRITE FILE
  
oReq.onprogress=function(event){
  console.log("progress");
   self.pgbar[fname]=(event.loaded/event.total);
   
}


console.log("progresssss")
    console.log(self.pgbar)
    oReq.onload = function(oEvent) {
      console.log("total");
      console.log(oEvent.total);
      
      console.log(oReq.response);
      const a = document.createElement('a');
          document.body.appendChild(a);
          const ur = window.URL.createObjectURL(oReq.response);
          a.href = ur;
          a.download = fname;
          a.click();
    }
    oReq.send();
  }

  else if(this.platform.is("android")){
  
    var request: DownloadRequest = {
      uri:url,
      title: 'Campulse',
      description: 'Campus News',
      mimeType: ftype,
      visibleInDownloadsUi: true,
      notificationVisibility:NotificationVisibility.VisibleNotifyCompleted,
      destinationInExternalPublicDir:{
        dirType: 'Download',
        subPath: fname
      }
    };
    

    this.downloader.download(request)
    .then((location: string) =>{
        this.fileopener.open(location,ftype);
    })
    .catch((error: any) => alert(error));
  }

       
else if(this.platform.is("cordova"))
{ 
  console.log("cordova");
    let oReq = new XMLHttpRequest();
    oReq.open("GET", url, true);
    oReq.responseType = "blob"; 
    
oReq.onprogress=function(event){
  console.log("progress");
   self.pgbar[fname]=(event.loaded/event.total);
   
}
console.log("progresssss")
    console.log(self.pgbar)
    oReq.onload = function(oEvent) {
      console.log("total");
      console.log(oEvent.total);
      
      console.log(oReq.response);
      const a = document.createElement('a');
          document.body.appendChild(a);
          const ur = window.URL.createObjectURL(oReq.response);
          a.href = ur;
          a.download = fname;
          a.click();
    }
    oReq.send();
  }
 
}
  ngOnInit() {
    // this.nots();
    this.flist();
    this.view();
  }

}
