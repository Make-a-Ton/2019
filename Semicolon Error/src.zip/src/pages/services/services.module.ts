import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';
import { ComponentsModuleModule } from '../../cmpnts/components-module.module';
import { ServicesPage } from './services.page';

const routes: Routes = [
  {
    path: '',
    component: ServicesPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ComponentsModuleModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ServicesPage]
})
export class ServicesPageModule {}
