import { Component, OnInit } from '@angular/core';
import { DataService } from '../../service/data.service';
import { AuthService } from '../../service/auth.service';
import { ComponentserviceComponent } from '../../cmpnts/componentservice/componentservice.component';


@Component({
  selector: 'app-services',
  templateUrl: './services.page.html',
  styleUrls: ['./services.page.scss'],
})
export class ServicesPage implements OnInit {
  
  serv={dept:"",issue:"",date:""};
udet={uname:"", utype:"",dept:"", mob:"", id:""};

  constructor(  public dataService: DataService,
                public authService:AuthService
                ) {}


upserv()
{
   console.log(this.serv);
    let d=new Date();
    let dt=d.toLocaleDateString();
    this.serv.date=dt;
  this.dataService.upservice(this.serv).then(()=>console.log("success"));
}

  ngOnInit() {
    
  }

}
