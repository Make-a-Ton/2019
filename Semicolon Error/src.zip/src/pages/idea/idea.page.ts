import { Component, OnInit } from '@angular/core';
import { PopupComponent } from '../../cmpnts/popup/popup.component';
import { PopoverController } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { ModalComponent } from '../../cmpnts/modal/modal.component';
import { DataService } from '../../service/data.service';
import { AuthService } from '../../service/auth.service';
@Component({
  selector: 'app-idea',
  templateUrl: './idea.page.html',
  styleUrls: ['./idea.page.scss'],
})
export class IdeaPage implements OnInit {
idea: any;
  constructor( public popoverController: PopoverController,
               public modal:ModalController,
               private dataService: DataService,
               private authService: AuthService) { }


     async presentModal() {
     const modal = await this.modal.create({
     component: ModalComponent,
     componentProps: { data: 123 },
     cssClass: 'inset-modal',
     
      }); 
     await modal.present();
    }
  

  async presentPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: PopupComponent,
      event: ev,
      translucent: true
    });
    return await popover.present();
  }

  view()
  {
    this.dataService.v_idea().then((idea)=>{
      this.idea=JSON.parse(idea.data);
      console.log(this.idea);
    })
  }

  like(id)
  {
    var lid={id:"",uname:""}
    this.authService.uname().then((uname)=>{
     lid.id=id;
     lid.uname=uname;
     console.log(lid); 
     this.authService.like(lid).then((val)=>{
       console.log(val);
     })
    });
  }

  doRefresh(event)
  {
    this.dataService.v_idea().then((idea)=>{
      console.log(this.idea);
      event.target.complete();
    });
  }

  ngOnInit() 
  {
    this.view();
  }

}
