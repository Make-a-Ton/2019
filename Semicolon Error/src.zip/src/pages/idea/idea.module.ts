import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';


import { IonicModule } from '@ionic/angular';

import { IdeaPage } from './idea.page';
// import { ComponentsModuleModule } from '../../cmpnts/components-module.module';
import { PopupComponent } from '../../cmpnts/popup/popup.component';
import { ComponentsModuleModule } from '../../cmpnts/components-module.module'
const routes: Routes = [
  {
    path: '',
    component: IdeaPage
  } 
];

@NgModule({
  imports: [
    CommonModule,
    ComponentsModuleModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  entryComponents:[PopupComponent],
  declarations: [IdeaPage, PopupComponent ]
})
export class IdeaPageModule {}
