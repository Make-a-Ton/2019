import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicerequestsPage } from './servicerequests.page';

describe('ServicerequestsPage', () => {
  let component: ServicerequestsPage;
  let fixture: ComponentFixture<ServicerequestsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServicerequestsPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicerequestsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
