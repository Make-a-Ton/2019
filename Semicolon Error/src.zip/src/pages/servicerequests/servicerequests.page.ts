import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { DataService } from '../../service/data.service';

@Component({
  selector: 'app-servicerequests',
  templateUrl: './servicerequests.page.html',
  styleUrls: ['./servicerequests.page.scss'],
})
export class ServicerequestsPage implements OnInit {
servdata;
uname={email:""}
  constructor(
              public authService:AuthService,
              public dataService:DataService
  ) { }

  load()
  {
    this.dataService.v_service().then(res=>{
      
     this.servdata=res.data;
     console.log(this.servdata);
    });
  }

   
  doRefresh(event){
  
    this.dataService.v_service().then(data=>{
   
    //  alert("refresh");
       this.servdata=JSON.parse( data.data);
      
       if(this.servdata.length>0){
         console.log("length"+this.servdata.length);
         event.target.complete();
       }
      });
    }

  ngOnInit()
   {
    this.load();
  }

}
