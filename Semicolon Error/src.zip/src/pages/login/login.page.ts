import { Component, OnInit } from '@angular/core';
import { AlertController, MenuController } from '@ionic/angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import  { AuthService } from '../../service/auth.service';
import { DataService } from '../../service/data.service';
import { AngularFireMessaging } from '@angular/fire/messaging';
import { Platform } from '@ionic/angular';
import { FCM } from '@ionic-native/fcm/ngx';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})

export class LoginPage implements OnInit {
abc={"name":"","password":""}
x="-1";

fileToUpload: File = null;

loginForm: FormGroup;


tok={"uname":"", "utype":"","token":""};

error_messages = {
'uname':[
  {type: 'required', message: 'Email is required'},
  {type: 'minLength', message: 'Email should have a minimum length of 6 characters'},
  {type: 'maxLength', message: 'Email should only have a maximum length of 50 characters'},
  {type: 'pattern', message: 'Please enter a valid email'}
],

'password':[
  {type: 'required', message: 'Password is required'},
  {type: 'minLength', message: 'Password should have a minimum length of 6 characters'},
  {type: 'maxLength', message: 'Password should only have a maximum length of 50 characters'},
  {type: 'pattern', message: 'Password must contain numbers, uppercase and lowercase letters'}
], 
}

  constructor(public alertController: AlertController, 
              public formBuilder: FormBuilder,
              private authService:AuthService, 
              private dataService: DataService,
              private afMessaging: AngularFireMessaging,
              private platform:Platform,
              private menu:MenuController,
              private fcm:FCM) { 

    this.loginForm=this.formBuilder.group({
      password: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(50),
        Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')

      ])),

      uname: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(50),
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))

    });

  }


  

  async presentAlert() {

    const alert = await this.alertController.create({
      header: 'Alert',
      subHeader:'Login',
      message: 'Username: '+this.abc.name+'<br>'+'Password: '+this.abc.password,
      buttons: ['OK']
    });

    await alert.present();
    
  }


 


  func(){

    this.authService.load("Loading...");
      this.authService.login1(this.loginForm.value).then((data: any)=>{

        //this.dataService.logres=+res;
   
        console.log(data);

    var a=JSON.parse(data.data);
    console.log(a["res"]);
    console.log(a);
        this.authService.loadingController.dismiss();
        this.authService.navCtrl.navigateForward(["profile"]);

        if(a["res"]==1)
        {
          console.log("uname");
          // alert(a.username);
          this.authService.storage.set('uname',a["username"]);
          this.authService.storage.set('utype',a["user"]);
          
          console.log(a["user"]);

          this.dataService.utype=a["user"];
          
      
        this.loginForm.reset();
        // this.dataService.id.uname=this.loginForm.value.uname;
       
        // this.authService.navCtrl.navigateForward(["profile"]);
        }
        else {
          this.authService.presentAlert(a);
        }
    });
    
  }
 
  ngOnInit() {
  
  }

  ionViewWillEnter() {
    this.menu.enable(false);
  }
    
  
}


