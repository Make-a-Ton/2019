import { Component, OnInit } from '@angular/core';
// import { File } from '@ionic-native/file/ngx'
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { AuthService } from '../../service/auth.service';
import { DataService } from '../../service/data.service';
import { Platform } from '@ionic/angular';
import { FileChooser } from '@ionic-native/file-chooser/ngx';
import { Storage } from '@ionic/storage';







@Component({
  selector: 'app-news',
  templateUrl: './news.page.html',
  styleUrls: ['./news.page.scss'],
})


export class NewsPage implements OnInit {
// upfile={name:"",type: MimeType,content:"",date:""};
cn="cn";
files: [];
pgarray:[];
// fref={ref:"uploadref"};

  constructor(private authService: AuthService,
     private dataService: DataService,  
     private fileOpener: FileOpener,
     public platform: Platform,
     private fileChooser: FileChooser,
    //  private file:File,
     private storage:Storage
    // private rpgbar:RoundProgressModule   
    ){
      
     }

     upfile={name:"",type: MimeType,content:"news"};
     fref={ref:"news"};
     fileToUpload: File = null;
   
     handleFileInput(event) {
       const fil=event.target.files;
       this.upfile.name=fil[0].name;
       this.upfile.type=fil[0].type;
       let files: FileList=event.target.files;
       this.fileToUpload = files.item(0);
       this.dataService.postFile(this.fileToUpload,this.upfile);
   }
    
 
  ngOnInit() {

 this.flist();
  }

  async flist(){
    
   
    await this.dataService.fileref(this.fref).then(data=>{
      console.log("news.ts")
      console.log(data.data);
      

     // this.dataService.pgbar.pop();
    
      this.files=JSON.parse( data.data);
      console.log(this.files);
     for(let x of this.files){
      this.dataService.pgbar[x["filename"]]=0;
      console.log("x");
      console.log(x);
     }
     console.log("pgbar");
     console.log(this.dataService.pgbar);
      });
  
  }


  dwnld(fname,ftype){
    console.log("type:  "+ftype);
    this.dataService.sample(fname);
    }




//   fchange(event){
//     const files=event.target.files;
//     console.log(files);
//     console.log(event)    
//     console.log(event.target);

//     let d=new Date();
//     let dt=d.toLocaleDateString();
    

//     this.upfile.name=files[0].name;
//     this.upfile.type=files[0].type;
//     this.upfile.content=this.cn;
//     this.upfile.date=dt;

//     console.log(this.upfile.type);
//     this.dataService.fileTransfers(this.upfile,"files"); // uploading info about upfile to db
//   this.dataService.uploads(event,"file/"+this.upfile.name)//uploading file to storage
//     .then((d)=>{
//       alert("Done");
//       this.dataService.fileref(this.fref).then(data=>{
//         this.files=JSON.parse( data.data);
//         });
//     }).catch((error)=>{
//       alert(JSON.stringify(error))
//     });
//  }


doRefresh(event){
  
  this.dataService.fileref((this.fref)).then(data=>{
 
  //  alert("refresh");
     this.files=JSON.parse( data.data);
     console.log(this.files);
    for(let x of this.files){
     this.dataService.pgbar[x["filename"]]=0;
     console.log("x");
     console.log(x);
     if(this.files.length>0){
       console.log("length"+this.files.length);
       event.target.complete();
     }
    }
    console.log("pgbar");
    console.log(this.dataService.pgbar);
     });
    
  }
}


