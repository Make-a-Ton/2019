import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LostindexPage } from './lostindex.page';

describe('LostindexPage', () => {
  let component: LostindexPage;
  let fixture: ComponentFixture<LostindexPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LostindexPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LostindexPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
