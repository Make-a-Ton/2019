import { Component, OnInit } from '@angular/core';
import { DataService } from '../../service/data.service';
// import { AngularFireUploadTask, AngularFireStorage} from 'angularfire2/storage';
// import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
// import { File } from '@ionic-native/file/ngx';

@Component({
  selector: 'app-lostindex',
  templateUrl: './lostindex.page.html',
  styleUrls: ['./lostindex.page.scss'],
})
export class LostindexPage implements OnInit {

  
  files: [];
  pgarray:[];
  
  did;

    // d=new FormData();
   
   

  constructor(private dataService: DataService, 
              // public file:File, 
              // public fileTransfer: FileTransfer, 
              // public afstorage: AngularFireStorage
              ) { }


  // transfer: FileTransferObject = this.fileTransfer.create();

  upfile={name:"",type: MimeType,content:"lost"};
  fref={ref:"lost"};
  fileToUpload: File = null;

  handleFileInput(event) {
    const fil=event.target.files;
    this.upfile.name=fil[0].name;
    this.upfile.type=fil[0].type;
    let files: FileList=event.target.files;
    this.fileToUpload = files.item(0);
    this.dataService.postFile(this.fileToUpload,this.upfile);
}
  
  fchangfe(event){
    const files=event.target.files;
    console.log(files);
    console.log(event)    
    console.log(event.target);
  
   
  
    this.upfile.name=files[0].name;
    this.upfile.type=files[0].type;
   
  
    console.log(this.upfile.type);
    this.dataService.fileTransfers(this.upfile,"lostindex"); // uploading info about upfile to db
  this.dataService.uploads(event,"lostindex/"+this.upfile.name)//uploading file to storage
    .then((d)=>{
      alert("Done");
      this.dataService.fileref(this.fref).then(data=>{
        this.files=JSON.parse( data.data);
        });
    }).catch((error)=>{
      alert(JSON.stringify(error))
    });
  }

  
  // fchange(event){
  //   const files=event.target.files;
  //   console.log(files);
  //   console.log(event)    
  //   console.log(event.target);
  
  //   let d=new Date();
  //   let dt=d.toLocaleDateString();
    
  
  //   this.upfile.name=files[0].name;
  //   this.upfile.type=files[0].type;
  //   this.upfile.date=dt;
  
  //   console.log(this.upfile.type);
  //   // this.dataService.fileTransfers(this.upfile,"lostindex"); // uploading info about upfile to db
  // this.dataService.sample(event)//uploading file to storage
  //   .then((d)=>{
  //     alert("Done");
  //     // this.dataService.fileref(this.fref).then(data=>{
  //     //   this.files=JSON.parse( data.data);
  //     //   });
  //   }).catch((error)=>{
  //     console.log("error");
  //     console.log(error);
  //     // alert(JSON.stringify(error))
  //   });
  // }
  
  async flist(){
    
   
    await this.dataService.fileref(this.fref).then(data=>{
      console.log("news.ts")
      console.log(data.data);
      

     // this.dataService.pgbar.pop();
    
      this.files=JSON.parse( data.data);
      console.log(this.files);
     for(let x of this.files){
      this.dataService.pgbar[x["filename"]]=0;
      console.log("x");
      console.log(x);
     }
     console.log("pgbar");
     console.log(this.dataService.pgbar);
      });
  
  }
  
  // dwnld(fname,ftype){
  // console.log("type:  "+ftype);
  // this.dataService.dwnlds(fname,ftype,"lostindex");
  // }

  dwnld(fname,ftype){
    console.log("type:  "+ftype);
    this.dataService.sample(fname);
    }
  
  
  doRefresh(event){
  
    this.dataService.fileref((this.fref)).then(data=>{
   
    //  alert("refresh");
       this.files=JSON.parse( data.data);
       console.log(this.files);
      for(let x of this.files){
       this.dataService.pgbar[x["filename"]]=0;
       console.log("x");
       console.log(x);
       if(this.files.length>0){
         console.log("length"+this.files.length);
         event.target.complete();
       }
      }
      console.log("pgbar");
      console.log(this.dataService.pgbar);
       });
      
    }

    s()
    {
      this.dataService.sample(event);
    }
  
    ngOnInit() {
      this.flist();
    }

}
