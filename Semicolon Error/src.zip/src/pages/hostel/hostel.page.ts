import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hostel',
  templateUrl: './hostel.page.html',
  styleUrls: ['./hostel.page.scss'],
})
export class HostelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
