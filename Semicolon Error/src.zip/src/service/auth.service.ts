import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { HTTP } from '@ionic-native/http/ngx';
import { catchError, tap} from 'rxjs/operators';
import { AlertController, MenuController } from '@ionic/angular';
import { LoadingController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Storage } from '@ionic/storage';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

url = environment.url;


  constructor(private httpclient:HttpClient,
       public alertController: AlertController,
       public loadingController: LoadingController,
       public navCtrl: NavController,
       private http:HTTP,
       public storage:Storage,
       public router: Router,
       public menu:MenuController
       ) { }


studreg(data)
{
  console.log(data);
 return this.httpclient.post(`${this.url}/studreg`, data ).pipe(
    catchError(e => {
      console.log(e.error.msg);
      throw new Error(e);
    })
  );
  
}

treg(data)
{console.log("treg in auth");
  console.log(data);
 return this.httpclient.post(`${this.url}/treg`, data ).pipe(
    catchError(e => {
      console.log(e.error.msg);
      throw new Error(e);
    })
  );
}

ntreg(data)
{
  console.log(data);

 return this.httpclient.post(`${this.url}/ntreg`, data ).pipe(
    catchError(e => {
      console.log(e.error.msg);
      throw new Error(e);
    })
  );
}

areg(data)
{
  console.log(data);
 return this.httpclient.post(`${this.url}/areg`, data ).pipe(
    catchError(e => {
      console.log(e.error.msg);
      throw new Error(e);
    })
  );
}


login(data)
{
  console.log(data);
 return this.httpclient.post(`${this.url}/login`, data ).pipe(tap(res=>{
   console.log("service")
   console.log(res["res"]);
  alert("user: "+res["user"]);
   this.storage.set('utype',res["user"]);

    catchError(e => {
      console.log(e.error.msg);
      throw new Error(e);
    })
  }));
}

user()
{
 return this.storage.get('utype');
}

tok()
{
 return this.storage.get('token');
}

uname()
{
 return this.storage.get('uname');
}


login1(data)
{
  console.log(data);
 return this.http.post(`${this.url}/login`, data,{}).catch((err)=>{
   this.loadingController.dismiss();
   this.presentAlert("Login Again");
 })
}


async presentAlert(msg) {

  const alert = await this.alertController.create({
    header: 'Alert',
   // subHeader:
    message: msg,
    buttons: [
      {
        text: 'OK',
        cssClass: 'secondary',
        handler: () => {
        //  this.navCtrl.navigateForward("profile");
        }
      }
    ]
  });

  await alert.present();
  
}

async load(msg) {
  const loading = await this.loadingController.create({
    spinner: "dots",
    message: msg,
    translucent: true,
    duration: 4000
  });
  return await loading.present();
}

fileTransfer(data){
  console.log("in auth")
  console.log(data);
  return this.httpclient.post('https://thread-passbook.glitch.me/file', data);
}

tokens(data){
  console.log("in tokens at authservice:");
  console.log(data);
return this.http.post('https://thread-passbook.glitch.me/tokens',data,{});

}

notify(data)
{
  console.log(data);
  // alert("Sending Notification")
 return this.http.post('https://thread-passbook.glitch.me/notify', data,{});
}

logout(){
  
  this.menu.toggle();
  var t={token:""};
  this.tok().then((tokn)=>{
  //  t.token=tokn;
  //   return this.http.post('https://thread-passbook.glitch.me/deltoken',t,{}).then((res)=>{
  //     console.log("deltoken then");
      console.log(tokn);
      this.storage.clear();
      this.navCtrl.navigateForward(["login"]);
    }); 
  // });

 
}

dfserv(data)
{
 return this.http.post('https://thread-passbook.glitch.me/dfserv',data,{});
}

service(data)
{
  return this.http.post('https://thread-passbook.glitch.me/service',data,{});
}

tchr()
{
  return this.http.post('https://thread-passbook.glitch.me/tchr',{},{});
}

servcard(data)
{
  return this.http.post('https://thread-passbook.glitch.me/servcard',data,{});
}

p_idea(data)
{
  return this.http.post('https://thread-passbook.glitch.me/p_idea',data,{});
}
like(data)
{
  return this.http.post('https://thread-passbook.glitch.me/like',data,{}).then(res=>{

  console.log(res);
  })
}

}
