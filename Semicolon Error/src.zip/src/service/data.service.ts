import { Injectable } from '@angular/core';
import { HTTP } from '@ionic-native/http/ngx';
import { AngularFireUploadTask, AngularFireStorage} from 'angularfire2/storage';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer/ngx';
// import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { Platform } from '@ionic/angular';
import { Downloader, DownloadRequest, NotificationVisibility } from '@ionic-native/downloader/ngx';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class DataService {
  pgbar=[];
 public utype="";
 public uname="";
 fl=new FormData();

 //public uname="";

 id={"uname":"", "proref":""};

public sprodet: any=null;
  constructor(private http: HTTP,
              public afstorage: AngularFireStorage, 
              private transfer: FileTransfer, 
              // private file: File,
              private platform: Platform,
              private fileopener:FileOpener,
              private downloader: Downloader,
              private httpc: HttpClient
              ) { }

   filetransfer: FileTransferObject = this.transfer.create();

   upfile={name:"",type: MimeType,content:"lost",date:""};


  profile()
  {
 return this.http.post('https://thread-passbook.glitch.me/profile', this.id,{}); 
  }


fileTransfer(data)
  {
  console.log(data);
 return this.http.post('https://thread-passbook.glitch.me/file', data,{});
  }

fileTransfers(data,ref)
  {
  console.log(data);
 return this.http.post('https://thread-passbook.glitch.me/'+ref, data,{});
  }

dpref(data)
  {
  console.log(data);
 return this.http.post('https://thread-passbook.glitch.me/propic', data,{});
  }


fileref(data)
  {
 return this.http.post('https://thread-passbook.glitch.me/getfileinfo',data,{});
  }

  v_idea()
  {
    return this.http.post('https://thread-passbook.glitch.me/v_idea',{},{});
  }

  v_not()
  {
    return this.http.post('https://thread-passbook.glitch.me/v_not',{},{});
  }

  v_service()
  {
    return this.http.post('https://thread-passbook.glitch.me/v_service',{},{});
  }

  upservice(data)
  {
    return this.http.post('https://thread-passbook.glitch.me/upservice',data,{});
  }


  p_not(data)
{
  return this.http.post('https://thread-passbook.glitch.me/p_not',data,{});
}


uploads(event,loc): AngularFireUploadTask {
  alert("in uploads at dataservice");
  console.log(event);
  console.log(loc);
   return this.afstorage.ref(loc).put(event.target.files[0]);
  }

  dpupload(event,loc): AngularFireUploadTask {
    alert("in dpuploads at dataservice");
     return this.afstorage.ref(loc).put(event.target.files[0]);
    }

  dwnlds(fname, ftype,dname){
    // alert("fname service"+fname)
    // alert("filetype "+ftype);
    var fileref=this.afstorage.ref(dname).child(fname);
    
    fileref.getDownloadURL().subscribe((url)=>{
      console.log("Download Success");
     
      console.log(url);
      var self = this;
     
     
// if(this.platform.is("desktop"))
// {
  console.log("cordova");
    let oReq = new XMLHttpRequest();
    //SENDING REQUEST
    oReq.open("GET", url, true);
    oReq.responseType = "blob"; // blob pls
    // // oReq.setRequestHeader('Access-Control-Allow-Headers', '*');
  
    // //IF DATA RECEIVED THEN  WRITE FILE
  
oReq.onprogress=function(event){
  console.log("progress");
   self.pgbar[fname]=(event.loaded/event.total);
   
}


console.log("progresssss")
    console.log(self.pgbar)
    oReq.onload = function(oEvent) {
      console.log("total");
      console.log(oEvent.total);
      
      console.log(oReq.response);
      const a = document.createElement('a');
          document.body.appendChild(a);
          const ur = window.URL.createObjectURL(oReq.response);
          a.href = ur;
          a.download = fname;
          a.click();
    }
    oReq.send();
    
});
}

sample(fname)
{
//   let flist:FileList=event.target.files;
//   let files: File=flist[0];
//   this.fl.append('file',files,files.name);
//   console.log("test.php")
//   const data={"id":this.fl};
//   const headers={
//     'Origin':'http://13.235.71.103'
//   }
//  return this.http.post("http://13.235.71.103/test.php",data,headers).then((res)=>{
//     console.log("response")
//     console.log(res);

//   });
let uri="http://13.235.71.103/files/"+fname;
console.log(uri);
  let oReq = new XMLHttpRequest();
    //SENDING REQUEST
    oReq.open("GET",uri, true);
    oReq.responseType = "blob"; // blob pls
    // // oReq.setRequestHeader('Access-Control-Allow-Headers', '*');
  
    // //IF DATA RECEIVED THEN  WRITE FILE
 

console.log("progresssss")
    // console.log(self.pgbar)
    oReq.onload = function(oEvent) {
      console.log("total");
      console.log(oEvent.total);
      
      console.log(oReq.response);
      const a = document.createElement('a');
          document.body.appendChild(a);
          const ur = window.URL.createObjectURL(oReq.response);
          a.href = ur;
          a.download = fname;
          a.click();
    }
    oReq.send();
    
}

postFile(fileToUpload: File,info) {
  const headers={
    'Origin':'http://13.235.71.103'
  }
  const endpoint = 'http://13.235.71.103/upload.php';
  const formData: FormData = new FormData();
  formData.append('fileKey', fileToUpload, fileToUpload.name);
  return this.httpc
    .post(endpoint, formData)
    .subscribe(() => {
      this.fileinfo(info);
      console.log("ss") ;

    });
}

fileinfo(ref)
{
  this.http.post('https://thread-passbook.glitch.me/fileinfo',ref,{});
}

nots()
{
 return this.http.post('https://thread-passbook.glitch.me/notpage',{},{});
}
}