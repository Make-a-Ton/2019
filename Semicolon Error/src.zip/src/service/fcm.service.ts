import { Injectable } from '@angular/core';
import { AngularFireMessaging } from '@angular/fire/messaging';
// import { AngularFireFunctions } from '@angular/fire/functions';
import { ToastController } from '@ionic/angular';
import { tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class FcmService {
  token;

  constructor(  private afMessaging: AngularFireMessaging,
                // private func: AngularFireFunctions,
                // public app:FirebaseApp,
                private toastController: ToastController
              ) { }

              async makeToast(message) {
                const toast = await this.toastController.create({
                  message,
                  duration: 5000,
                  position: 'top',
                  showCloseButton: true,
                  closeButtonText: 'dismiss'
                });
                toast.present();
              }

            
              
              showMessages() {
                return this.afMessaging.messages.pipe(
                  tap(msg => {
                    const body: any = (msg as any).notification.body;
                    this.makeToast(body);
                  })
                );
              }

      //         pushnot(topic) {

      //          this.func.httpsCallable('sendToDeviceGroup')({topic, token: this.token}).pipe(
      //            tap(_ => this.makeToast(topic))).subscribe();

      // }
  } 
        