import 'package:best_flutter_ui_templates/fitnessApp/models/tabIconData.dart';
import 'package:best_flutter_ui_templates/fitnessApp/traning/trainingScreen.dart';
import 'package:flutter/material.dart';
import 'bottomNavigationView/bottomBarView.dart';
import 'fintnessAppTheme.dart';
import 'myDiary/myDiaryScreen.dart';

class FitnessAppHomeScreen extends StatefulWidget {
  @override
  _FitnessAppHomeScreenState createState() => _FitnessAppHomeScreenState();
}

class _FitnessAppHomeScreenState extends State<FitnessAppHomeScreen>
    with TickerProviderStateMixin {

  // double KSEBPredictor(int no_bills, double average_bill) {
  //     int slab;
  //     int security_deposit =
  //
  //     if(average_bill <= 280) { slab = 1;}
  //     else if (average_bill > 280 && average_bill < 640) { slab = 2;}
  //     else if (average_bill > 640 && average_bill < 1260) {slab = 3;}
  //     else if (average_bill > 1260 && average_bill < 2320) { slab = 4;}
  //     else {slab = 5;}
  //
  // }

  double powerCalculator(double expectedBill) {
      var totalPower;
      if(expectedBill <= 280) { totalPower = expectedBill / 2.8;}
      else if (expectedBill > 280 && expectedBill < 640) { totalPower = expectedBill / 3.2;}
      else if (expectedBill > 640 && expectedBill < 1260) {totalPower = expectedBill / 4.2;}
      else if (expectedBill > 1260 && expectedBill < 2320) { totalPower = expectedBill / 5.8;}
      else {totalPower = expectedBill / 7;}

      return totalPower;
  }

  AnimationController animationController;

  List<TabIconData> tabIconsList = TabIconData.tabIconsList;



  Widget tabBody = Container(
    color: FintnessAppTheme.background,
    // child: new Column(
    //     mainAxisAlignment: MainAxisAlignment.center,
    //     children: <Widget>[
    //         new RaisedButton(
    //             child
    //         )
    //     ]
    // )
  );

  void getCost() {
    ;
  }

  @override
  void initState() {
    tabIconsList.forEach((tab) {
      tab.isSelected = false;
    });
    tabIconsList[0].isSelected = true;

    animationController =
        AnimationController(duration: Duration(milliseconds: 600), vsync: this);
    tabBody = MyDiaryScreen(animationController: animationController);
    super.initState();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: FintnessAppTheme.background,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body:

        FutureBuilder(
          future: getData(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return SizedBox();
            } else {
              return Stack(
                children: <Widget>[
                  tabBody,
                  // bottomBar(),
                ],
              );
            }
          },
        ),
        floatingActionButton: new FloatingActionButton(
            child: new Icon(Icons.add),
             onPressed: getCost,
        ),
      ),
    );
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return true;
  }

  Widget bottomBar() {
    return Column(
      children: <Widget>[
        Expanded(
          child: SizedBox(),
        ),
        BottomBarView(
          tabIconsList: tabIconsList,
          addClick: () {},
          changeIndex: (index) {
            if (index == 0 || index == 2) {
              animationController.reverse().then((data) {
                if (!mounted) return;
                setState(() {
                  tabBody =
                      MyDiaryScreen(animationController: animationController);
                });
              });
            } else if (index == 1 || index == 3) {
              animationController.reverse().then((data) {
                if (!mounted) return;
                setState(() {
                  tabBody =
                      TrainingScreen(animationController: animationController);
                });
              });
            }
          },
        ),
      ],
    );
  }
}
